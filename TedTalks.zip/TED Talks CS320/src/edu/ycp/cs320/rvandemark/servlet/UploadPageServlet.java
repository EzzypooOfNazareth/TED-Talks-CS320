package edu.ycp.cs320.rvandemark.servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.ycp.cs320.rvandemark.controller.UploadPageController;
import edu.ycp.cs320.rvandemark.model.Engine;
import edu.ycp.cs320.rvandemark.model.User;
import edu.ycp.cs320.rvandemark.model.Video;

public class UploadPageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	UploadPageController controller = null;
	// Get material from page
	
	// built based of reference from Hake's Lab02 Example
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// Login in determiner written by Don Hake
		User user = (User)req.getSession().getAttribute("user");
		if (user == null) {
			System.out.println("   User: <" + user + "> not logged in or session timed out");
			// user is not logged in, or the session expired
			resp.sendRedirect(req.getContextPath() + "/loginPage");
			return;
		}
		System.out.println("In the Upload Page servlet");
		req.getRequestDispatcher("/_view/uploadPage.jsp").forward(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		System.out.println("UploadPageServlet: doPost");	
		String video_url = req.getParameter("video_url");
		User user = (User)req.getSession().getAttribute("user");
		String successMessage = null;

		// Tests to assure the URL space was not empty
		if (video_url == null || video_url.isEmpty()) {
			video_url = "URL is Empty";
		} 
		//The Url is tested for validity and then the embedURL, name, speaker, thumbnail, ratings, dates, and disciplines
		// are gathered and sent to the controller for insertion into the database
		else {
			System.out.println(video_url + " made it!");
			controller = new UploadPageController();
			try {
				if (Engine.videoIsValid(video_url) == false) {
					Video video = new Video (video_url, 0, 0);
					String e_url = video.getEmbedUrl();
					String name = video.getName();
					String speaker = video.getSpeaker();
					String thumb = video.getThumbnailUrl();
					int tr = 0;
					int nr = 0;
					double rating = 0.0;
					int uploadMonth = video.getUploadMonth();
					int uploadDay = video.getUploadDay();
					int uploadYear = video.getUploadYear();
					String discipline_line = video.getDisciplineLine();
					// If the insertion is successfull (true) then the successmessage in changed to the name
					if(controller.insertVideo(video_url, e_url, name, speaker, thumb, tr, nr, rating, uploadMonth, uploadDay, uploadYear, discipline_line)){
						successMessage = name;
						// attempts to take user to new video page
						// give user two points if upload is successful - w3schools
						// Engine.giveUserSetPoints(user, 2);
						req.getSession().setAttribute("video", video);
						resp.sendRedirect("/rvandemark/videoDisplay");
						return;
					}
					//test else
					else {
						video_url = "URL is not valid/Already exists";
						System.out.println("URL was not valid/Already Exists");
						req.getSession().setAttribute("video_url", video_url);
						resp.sendRedirect(req.getContextPath() + "/uploadPage");
						return;
					}
				}
				else {
					//if the video url already exists or is not a ted.com url, then the user is redirected to the uploadPage
					video_url = "URL is not valid/Already exists";
					System.out.println("URL was not valid/Already Exists");
					req.getSession().setAttribute("video_url", video_url);
					resp.sendRedirect(req.getContextPath() + "/uploadPage");
					return;
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		req.setAttribute("successMessage", successMessage);
		req.getRequestDispatcher("/_view/uploadPage.jsp").forward(req, resp);
	}
}