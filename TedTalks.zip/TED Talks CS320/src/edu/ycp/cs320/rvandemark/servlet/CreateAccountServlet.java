package edu.ycp.cs320.rvandemark.servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import edu.ycp.cs320.rvandemark.model.Engine;
import edu.ycp.cs320.rvandemark.model.User;
public class CreateAccountServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		
		System.out.println("In the Create Account Page servlet");
		
		req.getRequestDispatcher("/_view/createAccount.jsp").forward(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//code structure comes from InsertBookServlet by DJHake
		String email = null;
		String emailRepeat = null;
		String screenName = null;
		String password = null;
		String passwordRepeat = null;
		String lastName = null;
		String firstName = null;
		int[] discipline_ids = new int[]{1};
		
		String errorMessage = null;
		String errorMessage2 = null;
		String errorMessage3 = null;
		String errorMessage4 = null;
		User user = null;
		
		
		/*emvalid = new EmailValidator();
		if (emvalid.validate(email)){	
		}else{
			errorMessage = "Invalid Email";
		}
		*/
		password = req.getParameter("password");
		passwordRepeat = req.getParameter("passwordRepeat");
		email = req.getParameter("email");
		emailRepeat= req.getParameter("emailRepeat");
		screenName = req.getParameter("screenName");
		lastName = req.getParameter("lname");
		firstName = req.getParameter("fname");
		
		
		
		try {
			user = Engine.getDB().getUserByEmail(emailRepeat);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if(!password.equals(passwordRepeat)){
			errorMessage = "Password fields must Match";
		}
		else if(!email.equals(emailRepeat)){
			errorMessage2 = "email must match";
		}
		else if (emailRepeat.equals(user.getEmail())){
			errorMessage3 = "User already exist with that email";
		}
		else if (!email.equals(emailRepeat)&&!password.equals(passwordRepeat)){
			errorMessage4 = "User already exist with that email";
		}else{
			Engine.getDB().insertUser(email, screenName, passwordRepeat, lastName, firstName, discipline_ids, false);
			resp.sendRedirect(req.getContextPath() + "/landingPage");
		}
		
		req.setAttribute("fname", firstName);
		req.setAttribute("lname", lastName);
		req.setAttribute("email", email);
		req.setAttribute("password", password);
		req.setAttribute("passwordRepeat", passwordRepeat);
		req.setAttribute("screenName",   screenName);
		req.setAttribute("disc", discipline_ids);
		
		req.setAttribute("errorMessage", errorMessage);
		req.setAttribute("errorMessage2", errorMessage2);
		req.setAttribute("errorMessage3", errorMessage3);
		req.setAttribute("errorMessag4", errorMessage4);
		
		req.getRequestDispatcher("/_view/createAccount.jsp").forward(req, resp);
		

	}
}