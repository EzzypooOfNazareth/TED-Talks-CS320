package edu.ycp.cs320.rvandemark.controller;
import java.io.IOException;
import java.sql.SQLException;
import edu.ycp.cs320.rvandemark.model.Engine;

// UploadPageController is inspired by class examples given to the class by Don Hake
public class UploadPageController {
	
	public UploadPageController() {
		
	}
	public boolean insertVideo(String url, String e_url, String name, String speaker, String thumb, int tr, int nr, double rating, int uM, int uD, int uY, String dLine) throws SQLException, IOException {
		if (Engine.getDB().getVideoByURL(url) == false) {
			//Tests the input of the URL and information
			Integer new_video = Engine.getDB().insertVideo(url, e_url, name, speaker, thumb, tr, nr, rating, uM, uD, uY, dLine);
			//if the video_id returns zero or null, then the insertion has failed
			if (new_video > 0) {
				System.out.println("New URL (ID: " + new_video + ") successfully added to Videos table: <" + url + ">");
				System.out.println("Sending to videoDisplay...");
				return true;
			}
			else{
				return false;
			}
		}
		else {
			return false;
		}
	}
}