package edu.ycp.cs320.rvandemark.model;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class EngineTest {

	// Valid URL's must be replaced after each test as they are entered into the database/Delete the database
	
	private String validUrl_1 = "https://www.ted.com/playlists/343/street_art";
	private String validUrl_2 = "https://www.ted.com/talks/thomas_hellum_the_world_s_most_boring_television_and_why_it_s_hilariously_addictive";
	private String invalidUrl = "https://www.memrise.com/home/";
	
	
	@Before
	public void setUp() {
		Engine.getDB();
	}
	
	@Test
	public void testVideoIsValid() {
		assertFalse(Engine.videoIsValid(validUrl_1));
		assertFalse(Engine.videoIsValid(validUrl_2));
		assertTrue(Engine.videoIsValid(invalidUrl));
	}
}
