package edu.ycp.cs320.rvandemark.model;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class SearchPageModelTest {

	
	private String sT, fId, sId;
	private Integer s, f;
	
	private SearchPageModel spm;
	
	@Before
	public void setUp() {
		spm = new SearchPageModel();
		
		sT = "Seach Term";
		fId= "Filter Index";
		sId = "Sort Index";
		
		s = 1;
		f = 2;
	}
	
	@Test
	public void testGetSortIndex() {
		spm.setSortIdx(sId);
		
		assertEquals(spm.getSortIdx(), sId);
		assertNotEquals(spm.getSortIdx(), fId);
	}
	
	@Test
	public void testGetSearchTerm() {
		spm.setSearchTerm(sT);
		
		assertEquals(spm.getSearchTerm(), sT);
		assertNotEquals(spm.getSearchTerm(), fId);
	}
	
	@Test
	public void testGetFilterIndex() {
		spm.setFilterIdx(fId);
		
		assertEquals(spm.getFilterIdx(), fId);
		assertNotEquals(spm.getFilterIdx(), sId);
	}
	
	@Test
	public void testGetStart() {
		spm.setStart(s);
		
		assertEquals(spm.getStart(), s);
		assertNotEquals(spm.getStart(), f);
	}
	
	@Test
	public void testGetFinish() {
		spm.setFinish(f);
		
		assertEquals(spm.getFinish(), f);
		assertNotEquals(spm.getFinish(), s);
	}
}
