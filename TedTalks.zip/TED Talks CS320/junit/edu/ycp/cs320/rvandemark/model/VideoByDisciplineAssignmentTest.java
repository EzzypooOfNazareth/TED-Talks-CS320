package edu.ycp.cs320.rvandemark.model;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class VideoByDisciplineAssignmentTest {

	private String n, d, p;
	private YCPClass ycp;
	private Admin a;
	private Integer am, ad, ay, dm, dd, dy, c;
	private int s;
	
	private VideoByDisciplineAssignment vda;
	
	@Before
	public void setUp() {
		n = "Test_n";
		d = "Test_d";
		p = "Test_p";
		am = 1;
		ad = 2;
		ay = 3;
		dm = 4;
		dd = 5;
		dy = 6;
		c = 7;
		s = 301;
		
		ycp = new YCPClass(a, n, p, s);
		
		vda = new VideoByDisciplineAssignment(ycp, n, am, ad, ay, dm, dd, dy, d, c);
	}
	
	@Test
	public void testGetDiscipline() {
		vda.setDiscipline(d);
		
		assertEquals(vda.getDiscipline(), d);
		assertNotEquals(vda.getDiscipline(), n);
	}
	
	@Test
	public void testGetCount() {
		vda.setCount(c);
		
		assertEquals(vda.getCount(), c);
		assertNotEquals(vda.getCount(), am);
	}
	
	
	@Test
	public void testGetAssignDate() throws Exception {
		vda.setAssignDate(ad);
		
		assertEquals(vda.getAssignDate(), ad);
		assertNotEquals(vda.getAssignDate(), am);
	}
}
