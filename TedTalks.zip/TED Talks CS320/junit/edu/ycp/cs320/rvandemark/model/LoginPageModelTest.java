package edu.ycp.cs320.rvandemark.model;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class LoginPageModelTest {

	
	private String email = "emoore13@ycp.edu";
	private String email2 = "rvandemark@ycp.edu";
	private String email_false = "ezzypooofnazareth@gmail.com";
	
	private String password = "p@$$word";
	private String password_false = "not my real password lololol";
	
	private LoginPageModel lpm;
	private LoginPageModel lpm2;
	private LoginPageModel lpm_false;
	
	@Before
	public void setUp() {
		lpm = new LoginPageModel(email, password);
		lpm2 = new LoginPageModel(email2, password);
		lpm_false = new LoginPageModel(email_false, password_false);
	}
	
	@Test
	public void testGetEmail() {
		assertEquals(email, lpm.getEmail());
		assertEquals(email2, lpm2.getEmail());
		assertEquals(email_false, lpm_false.getEmail());
		
		assertNotEquals(email_false, "robert@christianMingle.com");
	}
	
	@Test
	public void testGetPassword() {
		assertEquals(password, lpm.getPassword());
		assertEquals(password, lpm2.getPassword());
		assertEquals(password_false, lpm_false.getPassword());
		
		assertNotEquals(password_false, lpm.getPassword());
	}
	
	@Test 
	public void testIsValid() {
		//needed a validity detector
		assertFalse(lpm.isValid());
		assertFalse(lpm2.isValid());
		
		//further implementation of the isValid method is needed
		//assertFalse(lpm_false.isValid());
	}
}
