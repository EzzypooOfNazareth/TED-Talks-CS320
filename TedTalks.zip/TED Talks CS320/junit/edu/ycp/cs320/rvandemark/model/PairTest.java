package edu.ycp.cs320.rvandemark.model;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class PairTest {

	
	private String laL, laR;
	private Integer l, r;
	private Pair pair;
	
	@Before
	public void setUp() {
		laL = "label left";
		laR = "label right";
		
		l = 1;
		r = 2;
		
		pair = new Pair(laL, laR, l, r);
	}
	
	@Test
	public void testGetLabelLeft() {
		assertEquals(pair.getLabelLeft(), laL);
		assertNotEquals(pair.getLabelLeft(), "Test");
	}
	
	@Test
	public void testGetLabelRight() {
		assertEquals(pair.getLabelRight(), laR);
		assertNotEquals(pair.getLabelRight(), "Test");
	}
	
	@Test
	public void testGetLeft() {
		assertEquals(pair.getLeft(), l);
		assertNotEquals(pair.getLeft(), r);
	}
	
	@Test
	public void testGetRight() {
		assertEquals(pair.getRight(), r);
		assertNotEquals(pair.getRight(), l);
	}
	
	@Test
	public void testToString() {
		assertEquals(pair.toString(), "[" + laL + ": " + l + ", " + laR + ": " + r + "]");
	}
}
