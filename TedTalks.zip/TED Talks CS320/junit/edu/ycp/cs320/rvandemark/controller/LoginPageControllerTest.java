package edu.ycp.cs320.rvandemark.controller;

import edu.ycp.cs320.rvandemark.db.DerbyDatabase;
import edu.ycp.cs320.rvandemark.model.LoginPageModel;
import edu.ycp.cs320.rvandemark.controller.LoginPageController;

import static org.junit.Assert.*;

import java.io.IOException;

import org.junit.Before;
import org.junit.Test;

public class LoginPageControllerTest {

	private LoginPageModel lpm;
	private LoginPageController lpc;
	
	private LoginPageModel lpm_empty;
	private LoginPageController lpc_empty;
	
	
	private LoginPageModel lpm_invalid;
	private LoginPageController lpc_invalid;
	
	private String in_email = "ezzypooofnazareth@gmail.com";
	private String in_password = "ezzypoo";
	
	private String email = "emoore13@ycp.edu";
	private String password = "p@$$word";
	
	@Before
	public void setUp() {
		lpm = new LoginPageModel(email, password);
		lpc = new LoginPageController(lpm);
		
		lpm_empty = new LoginPageModel(null, null);
		lpc_empty = new LoginPageController(lpm_empty);
		
		lpm_invalid = new LoginPageModel(in_email, in_password);
		lpc_invalid = new LoginPageController(lpm_invalid);
	}
	
	@Test 
	public void testValidCredentials() {
		assertTrue(lpm.isValid());
	}
	
	@Test 
	public void testEmptyCredentials() {
		assertFalse(lpm_empty.isValid());
	}
	
	@Test
	public void testInvalidCredentials() {
		assertFalse(lpm_invalid.isValid());
	}
}
