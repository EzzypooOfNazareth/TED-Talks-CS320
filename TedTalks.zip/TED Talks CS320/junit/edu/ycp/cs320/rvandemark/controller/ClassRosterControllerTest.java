package edu.ycp.cs320.rvandemark.controller;

import edu.ycp.cs320.rvandemark.db.DerbyDatabase;

import static org.junit.Assert.*;

import java.io.IOException;

import org.junit.Before;
import org.junit.Test;

import edu.ycp.cs320.rvandemark.model.Engine;

public class ClassRosterControllerTest {

	public DerbyDatabase db = Engine.getDB();
	public ClassRosterController crc;
	
	@Before
	public void setUp() throws IOException {
		crc = new ClassRosterController();
		System.out.println(db.getAllUsers().toString());
	}
	
	
	@Test
	public void testGetAllUsersInController() throws IOException {
		assertEquals(crc.getAllUsers(), db.getAllUsers());
	}
}
