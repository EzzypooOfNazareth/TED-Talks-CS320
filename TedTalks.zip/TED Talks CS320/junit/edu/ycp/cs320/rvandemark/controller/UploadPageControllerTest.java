package edu.ycp.cs320.rvandemark.controller;

import static org.junit.Assert.*;

import java.io.IOException;
import java.sql.SQLException;

import org.junit.Before;
import org.junit.Test;

import edu.ycp.cs320.rvandemark.model.Engine;

public class UploadPageControllerTest {

	// Tests for the uploadPage controller && also tests certain aspects of the derby database
	private String videoTest_true = "https://www.ted.com/talks/bj_miller_what_really_matters_at_the_end_of_life#t-13088";
	private String videoTest_false = "http://www.duolingo.com/";
	
	@Test
	public void testValidity() {
		assertTrue(Engine.videoIsValid(videoTest_true));
		assertFalse(Engine.videoIsValid(videoTest_false));
	}
	
	@Test
	public void videoByUrlTest() throws SQLException, IOException {
		boolean int_true = Engine.getDB().getVideoByURL(videoTest_true);
		boolean int_false = Engine.getDB().getVideoByURL(videoTest_false);
		assertFalse(int_true);
		assertFalse(int_false);
	}
}
